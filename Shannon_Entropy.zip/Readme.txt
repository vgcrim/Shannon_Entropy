The Shannon_Entropy program is designed to calculate the 3D molecular Shannon  entropy
based on histograms of interatomic distances.

Shannon_Entropy.zip file includes 1 folder and 5 files:
1. Molecules contains 119 *.hin files.
2. Shannon_Entropy.exe is an executable file (MS Windows).
3. Main.f90 contains part of the program code.
4. Mol_List.txt is the input file. The first line is the number of files being processed (119).
The following lines contain the names of the structure files.
5. Output.txt is the output file and contains the following fields:
N - the molecule number;
Molecule - name of the file (molecule);
w - bin width (angstrom);
m - the number of bins;
H - Shannon entropy (bit)
6. Readme.txt - contains comments. 

To get started, you need to run the Shannon_Entropy.exe file and enter the necessary information:
Histogram type (1 - regular, 3 - modified);
Bin width (0.001...0.01 angstroms)

The calculation results are placed in the Output.txt file.
